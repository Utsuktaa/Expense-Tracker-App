function Budgets() {
    return (
      <div style={{ marginBottom: "2rem" }}>
        <h2>Budgets</h2>
        <p>Spending limits and progress tracking.</p>
      </div>
    );
  }
  
  export default Budgets;
  