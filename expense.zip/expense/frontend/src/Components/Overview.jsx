function Overview() {
    return (
      <div style={{ marginBottom: "2rem" }}>
        <h2>Overview</h2>
        <p>Summary of balances and financial insights.</p>
      </div>
    );
  }
  
  export default Overview;
  