function FinancialCharts() {
    return (
      <div style={{ marginBottom: "2rem" }}>
        <h2>Charts</h2>
        <p>Graphical representation of financial trends.</p>
      </div>
    );
  }
  
  export default FinancialCharts;
  