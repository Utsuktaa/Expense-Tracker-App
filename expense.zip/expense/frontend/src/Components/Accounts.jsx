function Accounts() {
    return (
      <div style={{ marginBottom: "2rem" }}>
        <h2>Accounts</h2>
        <p>Wallet, bank, and credit card details.</p>
      </div>
    );
  }
  
  export default Accounts;
  