const mongoose = require("mongoose");
const User = require("../models/user.model");
const bcrypt = require("bcryptjs");

const connectDB = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URL);
    console.log("DB Connection Successful");

    const user = await User.findOne({ role: "admin" });
    if (!user) {
      const hashedPassword = await bcrypt.hash(process.env.ADMIN_PASSWORD, 10);
      const user = new User({
        name: "admin",
        email: "admin123@gmail.com",
        password: hashedPassword,
        role: "admin",
      });
      await user.save();
      console.log("Admin Created Successfully");
    }
  } catch (error) {
    console.log("DB Connection Error");
  }
};

module.exports = connectDB;
