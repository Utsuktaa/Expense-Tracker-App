const Income = require("../models/income.model");
const Expense = require("../models/expense.model");
const getStartMonthAndEndMonth = require("../utils/startMonthAndEndMonth");

const getIncomesVsExpenses = async (req, res) => {
  try {
    const year = 2025;
    const totals = [];
    for (let index = 0; index < 12; index++) {
      const { startMonth, endMonth } = getStartMonthAndEndMonth(year, index);

      const incomes = await Income.find({
        user: req.user.userId,
        date: { $gte: startMonth, $lte: endMonth },
      }).select("amount date"); //fetch amount and date

      const totalIncome = incomes.reduce((accumulator, income) => {
        return accumulator + income.amount;
      }, 0);

      const expenses = await Expense.find({
        //fetch expense amount and date
        user: req.user.userId,
        date: { $gte: startMonth, $lte: endMonth },
      }).select("amount date");

      const totalExpense = expenses.reduce((accumulator, expense) => {
        return accumulator + expense.amount;
      }, 0);

      totals.push({
        income: totalIncome,
        expenses: totalExpense,
        name: new Date(year, index, 1).toLocaleString("default", {
          month: "long",
        }),
      });
    }

    // console.log(new Date(2025, 0, 1)); //0 - January
    res.status(200).json(totals);
  } catch (error) {
    console.log(error);
    res.status(500).json({ message: "Server Error" });
  }
};
const getThisMonthIncomeVsExpense = async (req, res) => {
  try {
    const today = new Date();
    const { startMonth, endMonth } = getStartMonthAndEndMonth(
      today.getFullYear(),
      today.getMonth()
    );
    //income
    const incomes = await Income.find({
      user: req.user.userId,
      date: { $gte: startMonth, $lte: endMonth },
    }).select("amount date"); //fetch amount and date

    const totalIncome = incomes.reduce((accumulator, income) => {
      return accumulator + income.amount;
    }, 0);

    //expense
    const expenses = await Expense.find({
      user: req.user.userId,
      date: { $gte: startMonth, $lte: endMonth },
    }).select("amount date");

    const totalExpense = expenses.reduce((accumulator, expense) => {
      return accumulator + expense.amount;
    }, 0);

    const data = [
      { name: "Income", value: totalIncome, color: "#22c55e" },
      { name: "Expenses", value: totalExpense, color: "#ef4444" },
    ];
    res.status(200).json(data);
  } catch (error) {
    console.log(error);
    res.status(500).json({ message: "Server Error" });
  }
};

const getEachDayIncomeAndExpense = async (req, res) => {
  try {
    let incomes = await Income.find({
      user: req.user.userId,
    })
      .select("amount date")
      .lean();

    let expenses = await Expense.find({
      user: req.user.userId,
    })
      .select("amount date")
      .lean();

    incomes = incomes.map((income) => ({
      ...income,
      type: "income",
    }));
    expenses = expenses.map((expense) => ({
      ...expense,
      type: "expense",
    }));

    const incomeAndExpense = [...incomes, ...expenses];
    incomeAndExpense.sort((a, b) => new Date(a.date) - new Date(b.date));

    let balance = 0;
    let result = [];
    for (let index = 0; index < incomeAndExpense.length; index++) {
      if (incomeAndExpense[index].type === "income") {
        balance += incomeAndExpense[index].amount;
      } else {
        balance -= incomeAndExpense[index].amount;
      }

      result.push({
        date: incomeAndExpense[index].date.toLocaleDateString("en-US", {
          month: "short",
          day: "numeric",
        }),
        balance,
      });
    }
    console.log(result);

    res.status(200).json(result);
  } catch (error) {
    console.log(error);
    res.status(500).json({ message: "Server Error" });
  }
};

module.exports = {
  getIncomesVsExpenses,
  getThisMonthIncomeVsExpense,
  getEachDayIncomeAndExpense,
};
