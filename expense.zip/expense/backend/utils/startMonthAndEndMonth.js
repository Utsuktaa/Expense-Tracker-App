const getStartMonthAndEndMonth = (year, month) => {
  const startMonth = new Date(year, month, 1);
  const endMonth = new Date(year, month, 31);
  return { startMonth, endMonth };
};
module.exports = getStartMonthAndEndMonth;
