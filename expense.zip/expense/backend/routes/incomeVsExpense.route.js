const {
  getIncomesVsExpenses,
  getThisMonthIncomeVsExpense,
  getEachDayIncomeAndExpense,
} = require("../controllers/incomeVsExpense.controller");

const verifyToken = require("../middlewares/auth.middleware");

const router = require("express").Router();
router.use(verifyToken);
router.get("/incomeVsExpense", getIncomesVsExpenses);
router.get("/thisMonthIncomeVsExpense", getThisMonthIncomeVsExpense);
router.get("/eachDayIncomeAndExpense", getEachDayIncomeAndExpense);
module.exports = router;
